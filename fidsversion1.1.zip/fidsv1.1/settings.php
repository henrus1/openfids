<?php

// Number of Departing Flights Displayed on the combi screen

$combidepartingflightsdisplayed = '3';

// Number of Arriving Flights Displayed on the combi screen

$combiarrivingflightsdisplayed = '3';

// Set Your Time Zone for the Onscreen Clock

// To Find your PHP time zone please visit http://php.net/manual/en/timezones.php

date_default_timezone_set("Australia/Brisbane");


?>